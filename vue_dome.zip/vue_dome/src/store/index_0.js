import Vue from 'vue'
import Vuex from 'vuex'

import { COUNTADD ,GETFOURS } from './mutation-types'
import {getFours} from '../api/common'

Vue.use(Vuex)

/*
    
    state：称为状态数，就是普通再普通一个 ｛｝

    getter : 相对于从state中派生数据出来 


    module 模块的意思，5* 优化代码结构
    

*/

const store = new Vuex.Store({ //创建仓库实例

      state:{
          count:2,
          fours:[]
        //   fours:[
        //       {name:"三和汽车",volov:false},
        //       {name:"建国汽车",volov:true},
        //       {name:"经典汽车",volov:false}
        //   ]
      },
      getters:{
          foursVolvo:function(state){
                
               return state.fours.filter((item)=>{
                     return !item.volov
               })
          }
      },
      mutations:{
         
        [COUNTADD]:function(state,type){ //key相对于事件的名称，value是事件的回调函数
              
            //在这里来做仓库数据的修改

            //mutation的回调函数。必须是一个同步函数，vue出来一个工具，通过这个工具要检测状态的每一次改变
            if(type=="add"){
                state.count += 1
            }else{
                state.count -= 1
            }
            

        },
        [GETFOURS]:function(state,fours){

             state.fours = [...state.fours,...fours] //合并数组

        }


      },
      actions:{ //做异步操作，操作成功后提交mutation
          
         actionFours:function(context){ //context就是 store的一个引用 

               //开始发请求 
            
               getFours({city:"CD"}).then((res)=>{

                      context.commit("GETFOURS",res.data.list)

               })


         }


      }



})



export default store
