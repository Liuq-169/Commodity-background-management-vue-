import { GETFOURS } from '../mutation-types'

import {getFours} from '../../user/common'

const fours = {
    state:{
        fours:[]
    },
    getters:{
        foursVolvo:function(state){
                
            return state.fours.filter((item)=>{
                  return !item.volov
            })
       }
    },
    mutations:{
        [GETFOURS]:function(state,fours){

            state.fours = [...state.fours,...fours] //合并数组

       }
    },
    actions:{

        actionFours:function(context){ //context就是 store的一个引用 

            //开始发请求 
         
            getFours({city:"CD"}).then((res)=>{

                   context.commit("GETFOURS",res.data.list)

            })


      }

    }
}

export default fours