import {COUNTADD,HANDLECOUNT,CHANGEUSERINFO } from '../mutation-types'

var  app = {
       
      state:{
          count:1,
          userInfo:{
              username:"",
              img:""
          }
      },
      mutations:{
        [HANDLECOUNT]:function(state,val){
              state.count = val
        },
        [CHANGEUSERINFO](state,userObj){
              
              state.userInfo.username = userObj.username

        },
        [COUNTADD]:function(state,type){ //key相对于事件的名称，value是事件的回调函数
              
            //在这里来做仓库数据的修改

            //mutation的回调函数。必须是一个同步函数，vue出来一个工具，通过这个工具要检测状态的每一次改变
            if(type=="add"){
                state.count += 1
            }else{
                state.count -= 1
            }
            

        }

      },
      actions:{

      }


}

export default app