import Vue from 'vue'
import Vuex from 'vuex'
import fours  from './modules/fours'
import app from './modules/app'


Vue.use(Vuex)

/*
    
    state：称为状态数，就是普通再普通一个 ｛｝

    getter : 相对于从state中派生数据出来 


    module 模块的意思，5* 优化代码结构
    

*/

const store = new Vuex.Store({ //创建仓库实例
    // strict: true,//所有的state的修改 都必须是提交 mutation ，强制报错。
     strict: process.env.NODE_ENV !== 'production',//在开发的时候才会打开，
     modules:{
        fours,
        app
     }
       

})



export default store
