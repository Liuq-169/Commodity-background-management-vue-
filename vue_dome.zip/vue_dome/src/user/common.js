import server from '../utils/request.js'

export function getFours(obj){ 
     return server({  //返回来的是一个 promise   
        method:"GET",
        url:"/api/getfours",
        params:obj
     })
}


//用户登录请求接口函数
export function getLogin(obj){
      
    return server({
           
       method:"POST",
       url:"/api/login",
       data:obj

    })

}

//获取分类列表请求接口函数
export function getCategoryList(obj){
   return server({

         method:'GET',
         url:'/api/manage/category/list',
         params:{...obj}
      
   })
}
//添加分类
export function getAddCategory(obj){
   return server({

         method:'POST',
         url:'/api/manage/category/add',
         data:{...obj}
      
   })
}
//修改分类
export function updateCategory(obj){
   return server({

         method:'POST',
         url:'/api/manage/category/update',
         data:{...obj}
      
   })
}





//获取商品分页列表
export function getProductList(obj){
   return server({

         method:'GET',
         url:'/api/manage/product/list',
         params:{...obj}
      
   })
}
//更换商品状态
export function replaceStatus(obj){
   return server({

         method:'POST',
         url:'/api/manage/product/updateStatus',
         data:{...obj}
      
   })
}
//搜索商品
export function searchList(obj){
   console.log(obj);
   
   return server({
         method:'GET',
         url:'/api/manage/product/search',
         params:{...obj}
      
   })
}
//添加商品
export function Addproduct(obj){
   return server({
         method:'POST',
         url:'/api/manage/product/add',
         data:{...obj}
   })
}
//更新商品
export function Updateproduct(obj){
   return server({
         method:'POST',
         url:'/api/manage/product/update',
         data:{...obj}
   })
}



//获取用户列表
export function getUserList(obj){
   return server({

         method:'GET',
         url:'/api/manage/user/list',
         params:{...obj}
      
   })
}
//更新用户
export function updateUser(obj){
   return server({

         method:'POST',
         url:'/api/manage/user/update',
         data:{...obj}
      
   })
}
//删除用户
export function delUser(obj){
   return server({

         method:'POST',
         url:'/api/manage/user/delete',
         data:{...obj}
      
   })
}
//添加用户
export function addUser(obj){
   return server({

         method:'POST',
         url:'/api/manage/user/add',
         data:{...obj}
      
   })
}



// 获取角色列表
export function getRoleList(obj){
   return server({

         method:'GET',
         url:'/api/manage/role/list',
         params:{...obj}
      
   })
}
//创建角色
export function addRole(obj){
   return server({

         method:'POST',
         url:'/api/manage/role/add',
         data:{...obj}
      
   })
}
//设置权限角色
export function updateRole(obj){
   return server({

         method:'POST',
         url:'/api/manage/role/update',
         data:{...obj}
      
   })
}



//获取订单列表
export function getOrderList(obj){
   return server({

         method:'GET',
         url:'/api/manage/order/list',
         params:{...obj}
      
   })
}
//搜索订单号
export function searchOrder(obj){
   return server({

         method:'GET',
         url:'/api/manage/order/search',
         params:{...obj}
      
   })
}
//获取订单详情
export function orderInfo(obj){
   return server({

         method:'GET',
         url:'/api/manage/order/info',
         params:{...obj}
      
   })
}





