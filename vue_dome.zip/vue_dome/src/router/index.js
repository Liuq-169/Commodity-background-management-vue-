import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import Login from '../views/Login.vue'
import Index from '../views/Index.vue'
import Category from '../views/Category.vue'
import Product from '../views/Product.vue'
import User from '../views/User.vue'
import Role from '../views/Role.vue'
import Order from '../views/Order.vue'
import ProductDetail from '../views/ProductDetail.vue'
import ProductAdd from '../views/ProductAdd.vue'
import ProductModify from '../views/ProductModify.vue'
import OrderDetail from '../views/OrderDetail.vue'


Vue.use(VueRouter)  //加载执行路由

const routes = [
  {
    path: '/home',
    redirect: '/home/index' //重定向
  },
  {
    path: '/home',
    name: 'home',
    component: Home,
    children: [{
      path: 'index',
      name: 'index',
      component: Index
    }, {
      path: 'category',
      name: 'category',
      component: Category
    }, {
      path: 'product',
      name: 'product',
      component: Product
    }, {
      path: 'user',
      name: 'user',
      component: User
    }, {
      path: 'role',
      name: 'role',
      component: Role
    }, {
      path: 'order',
      name: 'order',
      component: Order
    }, {
      path: 'ProductDetail',
      name: 'ProductDetail',
      component: ProductDetail
    }, {
      path: 'ProductAdd',
      name: 'ProductAdd',
      component: ProductAdd
    }, {
      path: 'ProductModify',
      name: 'ProductModify',
      component: ProductModify
    }, {
      path: 'OrderDetail',
      name: 'OrderDetail',
      component: OrderDetail
    }]
  },
  {
    path: '/login',
    name: 'login',
    component: Login
  },
  {
    path: '/about',
    name: 'about',
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  }
]

const router = new VueRouter({
  routes
})

export default router
