<template>
  <div class="product_box">
    <div class="header_box">
      <div class="header_left">
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
          <el-form-item>
            <el-select v-model="formInline.region" placeholder="按名称搜索">
              <el-option label="按名称搜索" :value="1"></el-option>
              <el-option label="按描述搜索" :value="2"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item>
            <el-input v-model="formInline.user" placeholder="关键字"></el-input>
          </el-form-item>

          <el-form-item>
            <el-button type="primary" @click="handlesearch">搜索</el-button>
          </el-form-item>
        </el-form>
      </div>

      <div class="header_rigth" @click="goProductAdd">+ 添加商品</div>
    </div>
    <div class="product_list">
      <el-table :data="tableData" style="width: 100%">
        <el-table-column label="商品名称" width="150" prop="name">
          <template slot-scope="scope">
            <div slot="reference" class="name-wrapper">
              <span>{{ scope.row.name }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="商品描述" prop="desc">
          <template slot-scope="scope">
            <div slot="reference" class="name-wrapper">
              <span>{{ scope.row.desc }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="商品价格" width="120" prop="price">
          <template slot-scope="scope">
            <div slot="reference" class="name-wrapper">
              <span>{{ scope.row.price }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="商品状态" width="150" prop="status">
          <template slot-scope="scope">
            <div slot="reference" class="name-wrapper">
              <el-button
                size="small"
                style="color=block"
                @click="handleStatus(scope.$index,scope.row)"
              >{{ getStatusLeft(scope.row.status) }}</el-button>
              <span
                style="margin-left:10px;color:rgb(64,158,255)"
              >{{ getStatusRigth(scope.row.status) }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="操作选项" width="150" prop="_id">
          <template slot-scope="scope">
            <el-button size="mini" @click="goDetaile(scope.row)">详情</el-button>
            <el-button size="mini" @click="goModify(scope.$index,scope.row)">修改</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="product_pagination">
      <el-pagination
        background
        layout="prev, pager, next"
        :total="total"
        :page-size="pageSize"
        :current-page="currentPage"
        @current-change="current_change"
      ></el-pagination>
    </div>
  </div>
</template>
<script>
import { getProductList } from "../user/common";
import { replaceStatus } from "../user/common";
import { searchList } from "../user/common";
export default {
  data() {
    return {
      tableData: [],
      currentPage: 1,
      pageSize: 4,
      total: 0,

      formInline: {
        user: "",
        region: ""
      }
    };
  },
  methods: {
    //获取商品列表
    setTableData() {
      getProductList({
        pageNum: this.currentPage,
        pageSize: this.pageSize
      }).then(res => {
        if (res.data.status == 0) {
          this.tableData = res.data.data.list;
          this.total = res.data.data.total;
        }
      });
    },
    //分页
    current_change(currentPage) {
      this.currentPage = currentPage;
      this.setTableData();
    },
    //上下架
    getStatusLeft(status) {
      if (status == 1) {
        return "下架";
      } else {
        return "上架";
      }
    },
    getStatusRigth(status) {
      if (status == 1) {
        return "销售中";
      } else {
        return "已下架";
      }
    },
    //更换商品状态
    handleStatus(index, row) {      
      replaceStatus({ productId: String(row._id), status: row.status }).then(res => {
        console.log(res);
        
        if (res.data.status == 0) {
          console.log(row);
          // console.log(rowId);
          if(this.tableData[index].status==1){
             this.tableData[index].status=0
          }else if(this.tableData[index].status==0){
             this.tableData[index].status=1
          };
          // this.setTableData()
        }
      });
    },
    //跳转详情页面
    goDetaile(row) {
      this.$router.push({
        path: "/home/ProductDetail",
        query: {
          _id: row._id,
          currentPage: this.currentPage
        }
      });
    },
    //跳转修改页面
    goModify(index, row) {
      this.$router.push({
        path: "/home/ProductModify",
        query: {
          _id: row._id,
          currentPage: this.currentPage,
          row: row
        }
      });
    },
    //跳转添加页面
    goProductAdd() {
      this.$router.push({
        path: "/home/ProductAdd",
        query: {
          tableData: this.tableData
        }
      });
    },
    //搜索
    handlesearch() {
      console.log(this.formInline.region);
      console.log(this.formInline.user);
      if (this.formInline.region == "1") {
        searchList({
          pageNum: 1,
          pageSize: this.pageSize,
          productName: this.formInline.region,
          productDesc: ""
        }).then(res => {
          console.log(res);
          if (res.data.status == 0) {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        });
      } else {
        searchList({
          pageNum: 1,
          pageSize: this.pageSize,
          productName: "",
          productDesc: this.formInline.user
        }).then(res => {
          console.log(res);
          if (res.data.status == 0) {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        });
      }
    },
    handleDelete(index, row) {
      console.log(index, row);
    },
    onSubmit() {
      console.log("submit!");
    }
  },
  mounted() {
    this.setTableData();
    this.current_change();
  }
};
</script>
<style lang="less">
.product_box {
  width: 100%;
  height: 520px;
  position: relative;
  overflow: hidden;
}

.header_box {
  width: 100%;
  height: 75px;
  padding: 0 15px;
  box-sizing: border-box;
  border-bottom: 1px solid gainsboro;
  margin-bottom: 30px;
}

.header_left {
  float: left;
  margin-top: 20px;
}

.header_rigth {
  float: right;
  font-size: 12px;
  line-height: 0px;
  height: 20px;
  background-color: rgba(64, 158, 255);
  margin-top: 20px;
  padding: 15px 18px;
  color: white;
  box-sizing: border-box;
  border-radius: 4px;
  cursor: pointer;
}

.product_list {
  border: 1px solid gainsboro;
  width: 95%;
  position: absolute;
  left: 50%;
  transform: translatex(-50%);
}

.product_pagination {
  position: absolute;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
}
</style>
