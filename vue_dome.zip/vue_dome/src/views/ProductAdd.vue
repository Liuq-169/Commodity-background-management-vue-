<template>
  <div>
    <template>
      <div class="D_wrapper">
        <div class="detaile_header">
          <i class="el-icon-back" @click="goProduct"></i>
          添加商品
        </div>

        <el-form
          :model="ruleForm"
          :rules="rules"
          ref="ruleForm"
          label-width="100px"
          class="demo-ruleForm"
        >
          <el-form-item label="商品名称" prop="name">
            <el-input v-model="ruleForm.name" placeholder="请输入商品名称"></el-input>
          </el-form-item>
          <el-form-item label="商品描述" prop="desc">
            <el-input type="textarea" v-model="ruleForm.desc" placeholder="请输入商品描述"></el-input>
          </el-form-item>
          <el-form-item label="商品价格" prop="price" placeholder="请输入商品价格">
            <el-input v-model="ruleForm.price"></el-input>
          </el-form-item>

          <div class="leixing" style="text-align: left">
            <el-form-item label="商品类型" prop="region">
              <el-select v-model="ruleForm.region" placeholder="请选择活动区域">
                <el-option
                  :label="typename.name"
                  :value="typename._id"
                  v-for="typename in typeName"
                  :key="typename._id"
                ></el-option>
              </el-select>
            </el-form-item>
          </div>
          <div class="img">
            <span>* 商品图片</span>
            <el-upload
              class="avatar-uploader"
              action="https://jsonplaceholder.typicode.com/posts/"
              :show-file-list="false"
              :on-success="handleAvatarSuccess"
              :before-upload="beforeAvatarUpload"
            >
              <img v-if="imageUrl" :src="imageUrl" class="avatar" />
              <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            </el-upload>
          </div>

          <el-form-item label="商品详情" prop="details">
            <el-input type="textarea" v-model="ruleForm.details" placeholder="请输入商品详情"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="submitForm('ruleForm')">确定提交</el-button>
            <el-button @click="resetForm('ruleForm')">重置</el-button>
          </el-form-item>
        </el-form>
      </div>
    </template>
  </div>
</template>
<script>
import { getCategoryList } from "../user/common";
import { Addproduct } from "../user/common";
export default {
  data() {
    return {
      ruleForm: {
        name: "", //名字
        desc: "", //描述
        price: "", //价格
        region: "", //类型
        details: "" //详情
      },
      typeName: "",
      rules: {
        name: [
          { required: true, message: "请输入商品名称", trigger: "blur" },
          { min: 1, max: 10, message: "长度在 1 到 10 个字符", trigger: "blur" }
        ],
        price: [
          { required: true, message: "请输入商品价格", trigger: "blur" },
          {
            min: 1,
            max: 1000,
            message: "长度在 1 到 1000 个字符",
            trigger: "blur"
          }
        ],
        region: [{ required: true, message: "请选择", trigger: "change" }],
        type: [
          {
            type: "array",
            required: true,
            message: "请至少选择一个活动性质",
            trigger: "change"
          }
        ],
        resource: [
          { required: true, message: "请选择活动资源", trigger: "change" }
        ],
        desc: [{ required: true, message: "请填写商品描述", trigger: "blur" }],
        details: [
          { required: true, message: "请填写商品详情", trigger: "blur" }
        ]
      },
      imageUrl: ""
    };
  },
  methods: {
    gettypeNameList() {
      getCategoryList({ parentId: 0, pageNum: 1, pageSize: 999 }).then(res => {
        console.log(res);
        if (res.data.status == 0) {
          this.typeName = res.data.data.list;
        }
        console.log(this.typeName);
      });
    },
    //确定提交
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          Addproduct({
            categoryId: this.ruleForm.region,
            pCategoryId: 0,
            name: this.ruleForm.name,
            desc: this.ruleForm.name.desc,
            price: this.ruleForm.price,
            detail: this.ruleForm.details,
            imgs: ""
          }).then(res => {
            console.log(res)
            console.log('添加成功');
          });
          alert("商品提交成功");
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    //重置
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    //返回主页面
    goProduct() {
      this.$router.push("/home/Product");
    },

    //图片上传
    handleAvatarSuccess(res, file) {
      this.imageUrl = URL.createObjectURL(file.raw);
    },
    beforeAvatarUpload(file) {
      const isJPG = file.type === "image/jpeg";
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!isJPG) {
        this.$message.error("上传头像图片只能是 JPG 格式!");
      }
      if (!isLt2M) {
        this.$message.error("上传头像图片大小不能超过 2MB!");
      }
      return isJPG && isLt2M;
    }
  },
  mounted() {
    this.gettypeNameList();
  }
};
</script>
<style lang="less" scoped>
.D_wrapper {
  padding-bottom: 15px;
}

.detaile_header {
  padding: 0px 35px 0px 35px;
  font-size: 20px;
  text-align: left;
  height: 80px;
  box-sizing: border-box;
  line-height: 80px;
}
.dareile_item {
  display: flex;
  justify-content: start;
  align-items: center;
  padding: 0 35px;
  height: 50px;
}

//图片上传
.avatar-uploader .el-upload {
  border: 1px dashed black;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader {
  border: 1px dashed rgb(150, 141, 141);
  margin-left: 20px;
  border-radius: 6px;
  cursor: pointer;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: rgb(44, 45, 46);
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}
.avatar {
  width: 178px;
  height: 178px;
  display: block;
}
.img {
  display: flex;
  justify-content: start;
  align-items: center;
  padding: 0 20px;
  font-size: 13px;
  color: #333333;
  margin: 10px 0;
}
</style>
