<template>
    <div class='wrapper'>
        <el-container class="l-contain">
          <div class='form-box'>
                <h2>登录</h2>
                <el-form status-icon :model="form" :rules="rules" ref="loginForm">
                    <el-form-item prop='username'>
                        <el-input placeholder="输入用户名" prefix-icon="el-icon-user" v-model="form.username"></el-input>
                    </el-form-item>
                    <el-form-item prop="password">
                        <el-input v-model="form.password" placeholder="请输入密码" type="password"  prefix-icon="el-icon-lock"></el-input>
                    </el-form-item>

                    <el-button type="primary" @click="onSubmit('loginForm')">
                        登录
                    </el-button>
                </el-form>
          
          </div>
            
        </el-container>
    </div>
</template>

<script>
//发送登录请求
import {getLogin} from '../user/common'
export default {
    data() {
        return {
            form:{
              username:"",
              password:""
           },
           rules:{
               username:[{ required: true, message: '用户名不能为空', trigger: 'blur' },
                         { min: 5, max: 12, message: '长度在 5 到 12 个字符', trigger: 'blur' }],
               password:[
                         { required: true, message: '密码不能为空', trigger: 'change' },
                         { len: 5, message: '长度为5位 ', trigger: 'change' }

               ]
           }
        }
    },
    methods: {
       onSubmit(loginForm){
           this.$refs[loginForm].validate((valid) => {
               if (valid) {
                   
                    
                     //调请求

                     getLogin(this.form).then((res)=>{
                       
                         if(!res.data.status){
                            
                            this.$store.commit("CHANGEUSERINFO",res.data.data)
                             sessionStorage.username = res.data.data.username
                            this.$router.push("/home")
                            console.log('登录成功')
                            
                         }

                     })


                } else {
                    console.log('发送失败')
                    this.$message('表单输入错误！');
                    return false;
                }
            });
        },
    },
}
</script>

<style lang="less">

    *{
        padding:0px;
        margin:0px
    }
    body,html{
        width:100%;
        height:100%
    }
    #app{
        width:100%;
        height:100%;
    }
    .wrapper{
        width:100%;
        height:100%;
        background-image: url('../../public/img/bgimg/bg.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
    }
    .l-contain{
        height:100%;
    }
    .form-box{
        width:400px;
        height:350px;
        margin:100px auto;
        padding:20px 40px;
        box-sizing: border-box;
        background-color: rgba(162,174,201,.8);
        line-height:65px
    }
    .form-box button{
        width:100%
    }
</style>