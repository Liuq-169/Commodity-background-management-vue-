<template>
  <div>
      <div class="Iwarp">
          <div class="content01">
              <div>
                  <el-progress type="dashboard" :percentage="25" color='rgba(245,108,108)'></el-progress>
                  <div class="ibutton">CPU使用率</div>
              </div>
              <div>
                  <el-progress type="dashboard" :percentage="55" color='rgba(230,162,60)'></el-progress>
                  <div class="ibutton">内存使用率</div>
              </div>
              <div>
                  <el-progress type="dashboard" :percentage="45"></el-progress>
                  <div class="ibutton">虚拟机使用率</div>
              </div>
              <div>
                  <el-progress type="dashboard" :percentage="60" color='rgb(230,162,60)'></el-progress>
                  <div class="ibutton">硬盘使用率</div>
              </div>
          </div>
          <div id="content02"></div>
          
      </div>
    
  </div>
</template>

<script>
export default {
  mounted() {
    this.drawLine();
  },

  methods: {
    drawLine() {
      
      // 基于准备好的dom，初始化echarts实例
      let content02 = this.$echarts.init(document.getElementById("content02"));
      content02.setOption({
        legend: {},
        tooltip: {
            trigger: 'axis',
            showContent: false
        },
        dataset: {
            source: [
                ['product', '2014', '2015', '2016', '2017', '2018', '2019'],
                ['Matcha Latte', 41.1, 30.4, 65.1, 53.3, 83.8, 98.7],
                ['Milk Tea', 86.5, 92.1, 85.7, 83.1, 73.4, 55.1],
                ['Cheese Cocoa', 24.1, 67.2, 79.5, 86.4, 65.2, 82.5],
                ['Walnut Brownie', 55.2, 67.1, 69.2, 72.4, 53.9, 39.1]
            ]
        },
        xAxis: {type: 'category'},
        yAxis: {gridIndex: 0},
        grid: {top: '55%'},
        series: [
            {type: 'line', smooth: true, seriesLayoutBy: 'row'},
            {type: 'line', smooth: true, seriesLayoutBy: 'row'},
            {type: 'line', smooth: true, seriesLayoutBy: 'row'},
            {type: 'line', smooth: true, seriesLayoutBy: 'row'},
            {
                type: 'pie',
                id: 'pie',
                radius: '30%',
                center: ['50%', '25%'],
                label: {
                    formatter: '{b}: {@2015} ({d}%)'
                },
                encode: {
                    itemName: 'product',
                    value: '2015',
                    tooltip: '2015'
                }
            }
        ]
    });



    }
  },
};
</script>
<style lang="less">

    .Iwarp{
        width: 100%;
        height: 100%;
    }

    .content01{
        overflow: hidden;
        display: flex;
        justify-content: space-around;
        margin-bottom: 15px
    }

    .content01>div{
        float: left;
        width: 220px;
        height: 200px;
        margin: 20px;
        border-radius: 8px;
        // padding: 25px 25px;
        box-sizing: border-box;
        display: flex;
        flex-direction: column;
        // flex-wrap: wrap;
        justify-content:space-around;
        align-items: center
        
    }

    .ibutton{
        width: 80px;
        height: 30px;
        background-color: rgb(240,249,235);
        text-align: center;
        font-size: 12px;
        border-radius: 4px;
        color: rgb(103,194,58);
        line-height: 30px
    }
    .content01>div:nth-of-type(1){
        background-color: rgba(103,194,58)
    }

    .content01>div:nth-of-type(2){
        background-color: rgba(230,162,60)
    }

    .content01>div:nth-of-type(3){
        background-color: rgba(245,108,108)
    }

    .content01>div:nth-of-type(4){
        background-color: rgba(144,147,153)
    }

    #content02{
        width: 100%;
        height: 600px;
        margin-bottom: 15px
    }

</style>