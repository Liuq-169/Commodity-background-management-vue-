<template>
    <div>
        <template>
            <div class="D_wrapper">
                <div class="detaile_header">
                    <i class="el-icon-back" @click="goProduct"></i>
                    商品详情
                </div>

                <div class="dareile_item">
                    <span class="el-tag el-tag--light" style="margin-right: 20px;">商品名称</span>
                    <span>{{detailList.name}}</span>
                </div>
                <el-divider><i class="el-icon-mobile-phone"></i></el-divider>

                <div class="dareile_item">
                    <span class="el-tag el-tag--light" style="margin-right: 20px;">商品描述</span>
                    <span>{{detailList.desc}}</span>
                </div>
                <el-divider><i class="el-icon-tickets"></i></el-divider>

                <div class="dareile_item">
                    <span class="el-tag el-tag--light" style="margin-right: 20px;">商品价格</span>
                    <span>{{detailList.price}}</span>
                </div>
                <el-divider><i class="el-icon-goods"></i></el-divider>

                <div class="dareile_item">
                    <span class="el-tag el-tag--light" style="margin-right: 20px;">所属分类</span>
                    <span>{{detailList.status}}</span>
                </div>
                <el-divider><i class="el-icon-star-off"></i></el-divider>

                <div class="dareile_item">
                    <span class="el-tag el-tag--light" style="margin-right: 20px;">商品图片</span>
                    <span :key='img' v-for='img in detailList.imgs'><img :src='img' style="width:50px;heigth:50px;margin-left:25px"></span>
                </div>
                <el-divider><i class="el-icon-bell"></i></el-divider>
                
                <div class="dareile_item">
                    <span class="el-tag el-tag--light" style="margin-right: 20px;">商品详情</span>
                    <span>{{detailList.desc}}</span>
                </div>
                <el-divider><i class="el-icon-s-promotion"></i></el-divider>
            </div>
        </template>
    </div>
</template>
<script>
import { getProductList } from "../user/common";
export default {
    data() {
      return {
        tableData: [],
        currentPage: 1,
        pageSize: 4,
        total:0,
        detailList:[]
      }
    },

    methods:{
        
        getTableData(){
             getProductList({}).then(res => {
                if(res.data.status==0){
                    
                    this.tableData=res.data.data.list
                    this.total=res.data.data.total
                    
                    this.detailList = this.tableData.find(item=>{
                        return item._id == this.$route.query._id
                    })
                    console.log(this.$route.query._id);
                }
            });
        },
        goProduct(){
            this.$router.push("/home/Product")
        }
    },
    mounted(){
        this.getTableData()
        // this.reload()
    }
}
</script>
<style lang="less" scoped>

    .D_wrapper{
        padding-bottom: 15px
    }
    
    .detaile_header{
        padding: 0px 35px 0px 35px;
        font-size: 20px;
        text-align: left;
        height: 80px;
        box-sizing: border-box;
        line-height: 80px;
    }
    .el-icon-back{
        cursor: pointer;
    }
    .dareile_item{
        display: flex;
        justify-content: start;
        align-items: center;
        padding: 0 35px;
        height: 50px;
    }
    
</style>
