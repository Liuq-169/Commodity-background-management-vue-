<template>
  
  <div class='user_box'>


        <div>
          <el-dialog title="添加用户" :visible.sync="dialogFormVisible_add" style="text-align: left">
            <el-form :model="form">
              <el-form-item label="*用户名" :label-width="formLabelWidth">
                <el-input v-model="userName" autocomplete="off"></el-input>
              </el-form-item>
              <el-form-item label="*密码" :label-width="formLabelWidth">
                <el-input v-model="password" autocomplete="off"></el-input>
              </el-form-item>
              <el-form-item label="*手机号" :label-width="formLabelWidth">
                <el-input v-model="phone" autocomplete="off"></el-input>
              </el-form-item>
              <el-form-item label="*邮箱" :label-width="formLabelWidth">
                <el-input v-model="email" autocomplete="off"></el-input>
              </el-form-item>
              <el-form-item label="*角色" :label-width="formLabelWidth">
                <el-select v-model="form.status" placeholder="请选择活动区域">
                  <el-option
                  :label="rolename.name"
                  :value='rolename._id'
                  v-for="rolename in tableDataRoles" 
                  :key="rolename._id">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
              <el-button @click="dialogFormVisible_add = false">取 消</el-button>
              <el-button type="primary" @click="DeteAdd">确 定</el-button>
            </div>
          </el-dialog>
        </div>

         <div>

          <el-dialog title="修改用户" :visible.sync="dialogFormVisible" style="text-align: left">
            <el-form :model="form">
              <el-form-item label="*用户名" :label-width="formLabelWidth">
                <el-input v-model="userName" autocomplete="off"></el-input>
              </el-form-item>
              <el-form-item label="*邮箱" :label-width="formLabelWidth">
                <el-input v-model="email" autocomplete="off"></el-input>
              </el-form-item>
              <el-form-item label="*电话" :label-width="formLabelWidth">
                <el-input v-model="phone" autocomplete="off"></el-input>
              </el-form-item>
              <el-form-item label="*角色" :label-width="formLabelWidth">
                <el-select v-model="form.status" placeholder="请选择活动区域">
                  <el-option
                  :label="rolename.name"
                  :value='rolename._id'
                  v-for="rolename in tableDataRoles" 
                  :key="rolename._id">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
              <el-button @click="dialogFormVisible = false">取 消</el-button>
              <el-button type="primary" @click="DeteUpdate">确 定</el-button>
            </div>
          </el-dialog>

        </div>

        <div class="header_box">
          <div class="header_left" @click="handleAdd">
             创建用户
          </div>
          
        </div>
        <div class="user_list">
            <el-table
              :data="tableData"
              style="width: 100%">
              <el-table-column
                label="用户名"
                width="150"
                prop='username'
                >
                <template slot-scope="scope">
                    <div slot="reference" class="name-wrapper">
                      <span>{{ scope.row.username }}</span>
                    </div>
                </template>
              </el-table-column>

              <el-table-column
                label="邮箱"
                width="180"
                prop='email'
                >
                <template slot-scope="scope">
                    <div slot="reference" class="name-wrapper">
                      <span>{{ scope.row.email }}</span>
                    </div>
                </template>
              </el-table-column>

              <el-table-column
                label="电话"
                width="150"
                prop='phone'
                >
                <template slot-scope="scope">
                    <div slot="reference" class="name-wrapper">
                      <span>{{ scope.row.phone }}</span>
                    </div>
                </template>
              </el-table-column>

              <el-table-column
                label="注册时间"
                width="180"
                prop='create_time'
                >
                <template slot-scope="scope">
                    <div slot="reference" class="name-wrapper">
                      <span>{{ timestampToTime(scope.row.create_time) }}</span>
                    </div>
                </template>
              </el-table-column>


               <el-table-column
                label="权限角色"
                width="150"
                prop='role_id'
                >
                <template slot-scope="scope">
                    <div slot="reference" class="name-wrapper">
                      <span>{{ user_roles(scope.row.role_id)  }}</span>
                    </div>
                </template>
              </el-table-column>

              <el-table-column  label="操作">
                <template slot-scope="scope">
                  <el-button
                    size="mini"
                    @click="handleUpdate(scope.$index, scope.row)">修改</el-button>
                  <el-button
                    size="mini"
                    @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                </template>
              </el-table-column>
            </el-table>
        </div>
        <div class="user_pagination">

            <el-pagination
              background 
              layout="prev, pager, next" 
              :total="total" 
              :page-size="pageSize"
              :current-page="currentPage"
              @current-change='current_change'
              >
            </el-pagination>

        </div>
       
        
  </div>

</template>
<script>
import { getUserList } from "../user/common";
import { updateUser } from "../user/common";
import { delUser } from "../user/common";
import { addUser } from "../user/common";


export default {
    data() {
      return {
        tableData: [],
        tableDataRoles:[],
        currentPage: 1,
        pageSize: 4,
        total:0,

        _id:'',
        userName:'',
        password:'',
        email:'',
        phone:'',
        rolename:'',
        role_id:'',
        

        dialogTableVisible: false,
        dialogFormVisible_add:false,
        dialogFormVisible: false,
        form: {
          name: '',
          status:'shanghai',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },
        formLabelWidth: '120px'
      }
    },
    methods: {
     //获取用户列表
      setTableData() {
        getUserList({pageNum:this.currentPage,pageSize:this.pageSize}).then(res => {
          if(res.data.status==0){
              console.log(res)
              this.tableData=res.data.data.list
              this.total=res.data.data.total
              this.tableDataRoles=res.data.data.roles
              console.log(this.tableDataRoles)
          }
        });
      },
      //分页
      current_change(currentPage){
       this.currentPage = currentPage;
       this.setTableData()
     },
     //时间戳转换函数
     timestampToTime(timestamp) {
        let date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
        let Y = date.getFullYear() + '-';
        let M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
        let D = date.getDate() + ' ';
        let h = date.getHours() + ':';
        let m = date.getMinutes() + ':';
        let s = date.getSeconds();
        return Y+M+D+h+m+s;
    },
    //权限角色
     user_roles(role_id){
        let tableDataRoles = this.tableDataRoles.find(item=>{
          return item._id == role_id
        })
        return tableDataRoles.name
     },

    //进入修改
      handleUpdate(index, row) {
        this.dialogFormVisible = true
        console.log(index, row);
        this._id = row._id
        this.userName = row.username
        this.email = row.email
        this.phone = row.phone
        this.role_id = this.form.status
      },
    //确定修改
    DeteUpdate(){
        this.dialogFormVisible = false
        updateUser({_id:this._id,username:this.userName,phone:this.phone,email:this.email,role_id:this.role_id}).then(res=>{
          console.log(res)
          this.userName = res.data.username
          this.email =  res.data.email
          this.phone = res.data.phone
          this.role_id = res.data._id
        })
        this.setTableData()
    },
    
    //删除
      handleDelete(index, row) {
        this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          console.log(row);
          
          delUser({userId:row._id}).then(res=>{
            if(res.data.status==0){
              console.log(res)
              this.$message({
                type: 'success',
                message: '删除成功!'
              });
              this.setTableData()
            }
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });          
        });
      },

    //进入添加用户
    handleAdd(){
        this.dialogFormVisible_add = true
        this._id = ''
        this.userName = ''
        this.email = ''
        this.phone = ''
        this.role_id = ''
    },
    //添加用户
    DeteAdd(){
        this.dialogFormVisible_add = false
        addUser({username:this.userName,password:this.password,phone:this.phone,email:this.email,role_id:this.role_id}).then(res=>{
          console.log(res)
        })
        this.setTableData()
    }

    },

    mounted() {
     this.setTableData();
     this.current_change()
    }
  }
</script>
<style lang="less" scoped>

    .user_box{
      width: 100%;
      height: 520px;
      position: relative;
      overflow: hidden;
    }

    .header_box{
      width: 100%;
      height: 75px;
      padding: 0 15px;
      box-sizing: border-box;
      border-bottom: 1px solid gainsboro;
      margin-bottom: 30px;
    }

    .header_left{
      float: left;
      font-size: 12px;
      line-height: 0px;
      height: 20px;
      background-color: rgba(64,158,255);
      margin-top: 20px;
      padding: 15px 18px;
      color: white;
      box-sizing: border-box;
      border-radius: 4px;
      cursor: pointer;
      margin-left: 10px
    }

    .user_list{
      border: 1px solid gainsboro;
      width: 95%;
      position: absolute;
      left: 50%;
      transform: translatex(-50%)
    }

    .user_pagination{
      position:absolute;
      bottom:20px;
      left: 50%;
      transform: translateX(-50%)
    }
</style>
