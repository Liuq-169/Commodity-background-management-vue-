<template>
    <div class='h-wrapper'>
    
          <el-container class='h-container'>
              <el-aside class='leftnav' style='width:220px;'>
                    <div class='header-logo'>
                        <img src="http://118.24.25.7:5000/img/logo.6f4321c1.png" alt="">
                    </div>
                    <ul class="el-admin-menu el-menu" style="background-color: rgb(43, 46, 51);">
                      
                      <el-col class='mueBox'>
                        <el-menu
                          default-active="2"
                          class="el-menu-vertical-demo"
                          @open="handleOpen"
                          @close="handleClose"
                          background-color="#000000"
                          text-color="#fff"
                          active-text-color="#ffd04b">
                          <el-menu-item index="2" @click='indexFn'>
                            <i class="el-icon-menu"></i>
                            <span slot="title">首页</span>
                          </el-menu-item>

                          <el-submenu index="1">
                            <template slot="title">
                              <i class="el-icon-s-home"></i>
                              <span>商品</span>
                            </template>
                            <el-menu-item-group>
                              <el-menu-item index="1-1" @click='categoryFn'>
                                <i class="el-icon-picture-outline-round"></i>
                                品类管理
                              </el-menu-item>
                              <el-menu-item index="1-2" @click='productFn'>
                                 <i class="el-icon-shopping-cart-1"></i>
                                商品管理
                              </el-menu-item>
                            </el-menu-item-group>
                          </el-submenu>
                        </el-menu>
                      </el-col>

                      <el-col class='mueBox'>
                        <el-menu
                          default-active="2"
                          class="el-menu-vertical-demo"
                          @open="handleOpen"
                          @close="handleClose"
                          background-color="#000000"
                          text-color="#fff"
                          active-text-color="#ffd04b">
                          <el-submenu index="1">
                            <template slot="title">
                              <i class="el-icon-s-custom"></i>
                              <span>用户</span>
                            </template>
                            <el-menu-item-group>
                              <el-menu-item index="1-1" @click='userFn'>
                                  <i class="el-icon-user"></i>
                                  用户管理
                              </el-menu-item>
                              <el-menu-item index="1-2" @click='roleFn'>
                                  <i class="el-icon-setting"></i>
                                  权限管理
                              </el-menu-item>
                            </el-menu-item-group>
                          </el-submenu>
                        </el-menu>
                      </el-col>

                      <el-col class='mueBox'>
                        <el-menu
                          default-active="2"
                          class="el-menu-vertical-demo"
                          @open="handleOpen"
                          @close="handleClose"
                          background-color="#000000"
                          text-color="#fff"
                          active-text-color="#ffd04b">
                          <el-submenu index="1">
                            <template slot="title">
                              <i class="el-icon-eleme"></i>
                              <span>订单</span>
                            </template>
                            <el-menu-item-group>
                              <el-menu-item index="1-1" @click='orderFn'>
                                <i class="el-icon-phone"></i>
                                订单管理
                              </el-menu-item>
                            </el-menu-item-group>
                          </el-submenu>
                        </el-menu>
                      </el-col>
                     </ul>
              </el-aside>

              <el-container class='h-right'>
                <el-header class='h-header'>
                    <div class='user_info'>
                      <span class='user_headerimg'><img src='https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'></span>
                      <span>{{username}}</span>
                      <span style='color:gary'>   |  </span>
      
                      <span style='font-size: 15px' class='close' @click="goLogin">退出</span>
                    </div>
                </el-header>
                <el-main class='h-main'>
                
                    <div class = 'h_mainBox'>
                        <router-view/>

                    </div>

                </el-main>
                <el-footer class='h-footer'>Created By Fiora At 2020.01</el-footer>
              </el-container>
          </el-container>
    
    </div>
</template>

<script>
     import { mapState } from 'vuex'
     export default {
      computed: {
          ...mapState({
              username:(state)=>{
                console.log(state)
                return state.app.userInfo.username || sessionStorage.username
              }
          })
      },

      methods: {
        handleOpen(key, keyPath) {
          console.log(key, keyPath);
        },
        handleClose(key, keyPath) {
          console.log(key, keyPath);
        },
        categoryFn(){
          this.$router.push('/home/category');
        },
        indexFn(){
          this.$router.push('/home/index');
        },
        productFn(){
          this.$router.push('/home/product');
        },
        userFn(){
          this.$router.push('/home/user');
        },
        roleFn(){
          this.$router.push('/home/role');
        },
        orderFn(){
          this.$router.push('/home/order');
        },
        goLogin(){
          this.$router.push("/login")
        }
      },
    }
</script>

<style lang="less">

       *{
        padding:0px;
        margin:0px
        }
        body,html{
            width:100%;
            height:100%
        }
        #app{
            width:100%;
            height:100%;
        }
        .h-container{
           height:100%
        }
        .h-wrapper{
            width:100%;
            height:100%;
        }

        //----------------leftnav------
        .h-container .leftnav{
             
             height:100%;
             background-color: rgba(43,46,51);
             z-index:999
             
        }

        .header-logo{
              width:220px;
              height:60px;
              background-color:rgba(43,46,51);
              padding:10px 30px;
              box-sizing: border-box;

        }

        .header-logo>img{
              width:100%;
              height:100%
        }

        .el-menu-item{
          display:flex;
          justify-content: start;
          align-items: center; 
        }

       .el-submenu__title {
          display:flex;
          justify-content: start;
          align-items: center; 
       }

       //------------------rigth content
       .h-header{
          box-shadow: 0 3px 3px rgba(0,0,0,.05);
          line-height:60px;
          z-index:999
       }
       .user_info{
          float:right;
          width:175px;
          height:100%;
          display: flex;
           justify-content: space-around;
          align-items: center;
       }

       .user_info>.user_headerimg{
         width:35px;
         height:35px;
         border-radius: 50%;
        display: inline-block;
        overflow:hidden
         
       }

        .user_headerimg>img{
          width:100%;
          height:100%
        }

        .close{
          cursor: pointer;
        }

       .h-main{
         background-color: rgba(243,243,243);
       }
       .h_mainBox{
         width: 100%;
         min-height: 520px;
         background-color: rgba(255,255,255);
         box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
         border-radius: 4px;
       }
       .h_mainBox>h1{
         line-height:200px
       }

       .h-footer{
          background-color: rgba(243,243,243);
          font-size:14px;
          line-height:60px;
          z-index:999
       }

  
</style>
