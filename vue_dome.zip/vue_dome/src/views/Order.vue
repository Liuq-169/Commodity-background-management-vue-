<template>
  <div class="order_box">
    <div class="header_box">
      <div class="header_left">
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
          <el-form-item>
            <el-select v-model="formInline.region" placeholder="按照订单号搜索">
              <el-option label="按照订单号搜索" value="1"></el-option>
              <el-option label="按照收件人搜索" value="2"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item>
            <el-input v-model="formInline.user" placeholder="订单号"></el-input>
          </el-form-item>

          <el-form-item>
            <el-button type="primary" @click="handleSearch">搜索</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <div class="order_list">
      <el-table :data="tableData" style="width: 100%">
        <el-table-column label="订单号" width="150" prop="create_time">
          <template slot-scope="scope">
            <div slot="reference" class="name-wrapper">
              <span>{{ scope.row.create_time }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="收件人" width="150" prop="recipient">
          <template slot-scope="scope">
            <div slot="reference" class="name-wrapper">
              <span>{{ scope.row.recipient }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="订单状态" width="150" prop="status">
          <template slot-scope="scope">
            <div slot="reference" class="name-wrapper">
              <span>{{ getStatus(scope.row.status) }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="订单总价" width="150" prop="allPrice">
          <template slot-scope="scope">
            <div slot="reference" class="name-wrapper">
              <span>￥{{ scope.row.allPrice }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="创建时间" width="180" prop="create_time">
          <template slot-scope="scope">
            <div slot="reference" class="name-wrapper">
              <span>{{ timestampToTime(scope.row.create_time) }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button size="mini" @click="goOrderDetail(scope.$index, scope.row)">查看详情</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="order_pagination">
      <el-pagination
        background
        layout="prev, pager, next"
        :total="total"
        :page-size="pageSize"
        :current-page="currentPage"
        @current-change="current_change"
      ></el-pagination>
    </div>
  </div>
</template>
<script>
import { getOrderList } from "../user/common";
import { searchOrder } from "../user/common";
export default {
  data() {
    return {
      tableData: [],
      currentPage: 1,
      pageSize: 4,
      total: 0,
      options: [
        {
          value: "选项1",
          label: "黄金糕"
        },
        {
          value: "选项2",
          label: "双皮奶"
        }
      ],
      formInline: {
        user: "",
        region: ""
      }
    };
  },
  methods: {
    setTableData() {
      getOrderList({ pageNum: this.currentPage, pageSize: this.pageSize }).then(
        res => {
          if (res.data.status == 0) {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
            console.log(res);
          }
        }
      );
    },
    current_change(currentPage) {
      this.currentPage = currentPage;
      this.setTableData();
    },
    timestampToTime(timestamp) {
      let date = new Date(timestamp); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
      let Y = date.getFullYear() + "-";
      let M =
        (date.getMonth() + 1 < 10
          ? "0" + (date.getMonth() + 1)
          : date.getMonth() + 1) + "-";
      let D = date.getDate() + " ";
      let h = date.getHours() + ":";
      let m = date.getMinutes() + ":";
      let s = date.getSeconds();
      return Y + M + D + h + m + s;
    },
    getStatus(status) {
      if (status == 1) {
        return "未支付";
      } else if (status == 0) {
        return "已支付";
      }
    },
    handleEdit(index, row) {
      console.log(index, row);
    },
    //跳转订单详情页面
    goOrderDetail(index, row) {
      console.log(index, row);
      this.$router.push({
        path: "/home/OrderDetail",
        query: {
          _id: row._id,
          // currentPage: this.currentPage
        }
      });
    },
    handleSearch() {
      if (this.formInline.region == "1") {
        searchOrder({
          type: 'orderId',
          value: this.formInline.user,
          pageNum: this.currentPage,
          pageSize: this.pageSize
        }).then(res => {
          console.log(res);
          if (res.data.status == 0) {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        });
      }else if(this.formInline.region == "2"){
        searchOrder({
          type: 'recipient',
          value: this.formInline.user,
          pageNum: this.currentPage,
          pageSize: this.pageSize
        }).then(res => {
          console.log(res);
          if (res.data.status == 0) {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        });
      }
      this.formInline.user=''
      this.formInline.region=''
    }
  },
  mounted() {
    this.setTableData();
  }
};
</script>
<style lang="less" scoped>
.order_box {
  width: 100%;
  height: 520px;
  position: relative;
  overflow: hidden;
}

.header_box {
  width: 100%;
  height: 75px;
  padding: 0 15px;
  box-sizing: border-box;
  border-bottom: 1px solid gainsboro;
  margin-bottom: 30px;
}

.header_left {
  float: left;
  margin-top: 20px;
}

.header_rigth {
  float: right;
  font-size: 12px;
  line-height: 0px;
  height: 20px;
  background-color: rgba(64, 158, 255);
  margin-top: 20px;
  padding: 15px 18px;
  color: white;
  box-sizing: border-box;
  border-radius: 4px;
  cursor: pointer;
}

.order_list {
  border: 1px solid gainsboro;
  width: 95%;
  position: absolute;
  left: 50%;
  transform: translatex(-50%);
}

.order_pagination {
  position: absolute;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
}
</style>
