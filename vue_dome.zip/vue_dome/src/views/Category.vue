<template>
  <div class="category_box" id="category_box">
    <div>
      <el-dialog title="添加分类" :visible.sync="dialogFormVisible" style="text-align:start">
        <el-form :model="form">
          <el-form-item label="分类名称" :label-width="formLabelWidth">
            <el-input v-model="categoryName" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="分类列表" :label-width="formLabelWidth">
            <el-select v-model="form.status" placeholder="请选择列表">
              <el-option label="一级分类" value="shanghai"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="getAddCategoryList">确 定</el-button>
        </div>
      </el-dialog>
    </div>
    <div class="header_box">
  
      <div class="header_left" style="margin-top:0px;" @click="returnParent" >一级商品分类列表</div>
      <span style="font-size:14px;float:left" v-html="showParentName">111</span>
      <!-- <div class="header_rigth"> -->
      <el-button
        type="primary"
        @click="dialogFormVisible = true"
        style="float: right;margin:15px 30px"
      >添加分类</el-button>
      <!-- </div> -->
    </div>
    <div class="category_list" id="category_list">
      <el-table :data="tableData" style="width: 100%">
        <el-table-column label="商品分类" prop="name">
          <template slot-scope="scope">
            <div slot="reference" class="name-wrapper">
              <span>{{ scope.row.name }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="操作分类" width="280" prop="_id">
          <template slot-scope="scope">
            <el-button size="mini" @click="handleModify(scope.$index, scope.row)">修改分类</el-button>
            <el-button size="mini" @click="handleChild(scope.$index, scope.row)" v-show='show'>查看子分类</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="category_pagination">
      <el-pagination
        background
        layout="prev, pager, next"
        :total="total"
        :page-size="pageSize"
        :current-page="currentPage"
        @current-change="current_change"
      ></el-pagination>
    </div>
  </div>
</template>
<script>
import { getCategoryList } from "../user/common";
import { getAddCategory } from "../user/common";
import { updateCategory } from "../user/common";

export default {
  computed: {
        showParentName() {
          return this.parentName
            ? `<i class="el-icon-right"></i>${this.parentName}`
            : "";
        }
  },
  data() {
    return {
      tableData: [],
      parentId: "0",
      currentPage: 1,
      pageSize: 5,
      total: 0,
      categoryName: "",
      parentName:'',
      show:true,
      
      

      dialogTableVisible: false,
      dialogFormVisible: false,
      formLabelWidth: "120px",
      form: {
        name: "",
        status: "shanghai",
        date1: "",
        date2: "",
        delivery: false,
        type: [],
        resource: "",
        desc: ""
      }
    };
  },
  methods: {
    handleModify(index, row) {
      // console.log(index, row);
      this.$prompt("请输入新分类名", "修改分类", {
        confirmButtonText: "确定",
        cancelButtonText: "取消"
      })
        .then(({ value }) => {
          console.log(value);
          updateCategory({
            categoryId: row._id,
            categoryName: value
          }).then(res => {
            console.log(res);
            if(res.data.status==0){
              console.log(row);
              this.setTableData()
              this.$message({
                type: "success",
                message: "添加成功"
              });
            }
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "取消输入"
          });
        });

      this.setTableData()
    },
    handleChild(index, row) {
      // console.log(index, row);
      this.parentName = row.name
      this.show=false,
      this.parentId = row._id;
      this.currentPage = 1
      this.setTableData()
    },
    returnParent(row){
        this.show=true
        this.parentId = '0'
        this.parentName = ''
        this.currentPage = 1
        this.setTableData()
    },
    setTableData() {
      getCategoryList({
        parentId: this.parentId,
        pageNum: this.currentPage,
        pageSize: this.pageSize
      }).then(res => {
        if (res.data.status == 0) {
          this.tableData = res.data.data.list;
          this.total = res.data.data.total;
        }
      });
    },
    current_change(currentPage) {
      this.currentPage = currentPage;
      this.setTableData();
    },
    getAddCategoryList() {
      this.dialogFormVisible = false;
      getAddCategory({
        parentId: this.parentId,
        categoryName: this.categoryName
      }).then(res => {
        console.log(res);
        setTableData();
      });
      this.categoryName = "";
    }
  },
  mounted() {
    this.setTableData();
    this.current_change();
  }
};
</script>
<style lang="less" scoped>
.category_box {
  width: 100%;
  height: 520px;
  position: relative;
  // overflow: hidden;
}



.header_box {
  width: 100%;
  height: 75px;
  padding: 0 15px;
  box-sizing: border-box;
  border-bottom: 1px solid gainsboro;
  margin-bottom: 30px;
  line-height: 75px;
}

.header_left {
  float: left;
  line-height: 75px;
  font-size: 13px;
  color: rgba(64, 158, 255);
}

.header_left:hover{
  cursor: pointer;
  color:green;
}

// .header_rigth {
//   // float: right;
//   // background-color: rgb(64,158,255);
//   // margin-top: 20px;
//   // // padding: 15px 18px;
//   // // box-sizing: border-box;
//   // border-radius: 4px;
// }

.category_list {
  border: 1px solid gainsboro;
  width: 95%;
  position: absolute;
  left: 50%;
  transform: translatex(-50%);
}

.category_pagination {
  position: absolute;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
}
</style>
