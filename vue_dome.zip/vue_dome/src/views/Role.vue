<template>
  <div class="role_box">
    <div class="header_box">
      <div class="header_left" @click="handleAdd">创建角色</div>
    </div>
    <div class="role_list">
      <el-table :data="tableData" style="width: 100%">
        <el-table-column label="角色名称" width="180" prop="name">
          <template slot-scope="scope">
            <div slot="reference" class="name-wrapper">
              <span>{{ scope.row.name }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="创建时间" width="190" prop="create_time">
          <template slot-scope="scope">
            <div slot="reference" class="name-wrapper">
              <span>{{ timestampToTime(scope.row.create_time) }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="授权时间" width="200" prop="auth_time">
          <template slot-scope="scope">
            <div slot="reference" class="name-wrapper">
              <span>{{ timestampToTime(scope.row.auth_time) }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="授权人" width="150" prop="auth_name">
          <template slot-scope="scope">
            <div slot="reference" class="name-wrapper">
              <span>{{ scope.row.auth_name }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button size="mini" @click="handleJurisdiction(scope.$index, scope.row)">设置权限</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="role_pagination">
      <el-pagination
        background
        layout="prev, pager, next"
        :total="total"
        :page-size="pageSize"
        :current-page="currentPage"
        @current-change="current_change"
      ></el-pagination>
    </div>
    <!-- 设置权限 -->
    <div>
      <el-dialog
        title="设置权限"
        :visible.sync="dialogVisible"
        width="50%"
        :before-close="handleClose"
        style="text-align: left"
      >
        <div style="margin-bottom: 30px;" class="jurisdiction">
          <el-tag>
            当前设置角色:
            <span>{{juese}}</span>
          </el-tag>
        </div>

        <div>
          <el-tree
            :data="data"
            show-checkbox
            node-key="id"
            :default-expanded-keys="[]"
            :default-checked-keys="[1,5,6]"
            :props="defaultProps"
          ></el-tree>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="DetermineJurisdiction">确 定</el-button>
        </span>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import { getRoleList } from "../user/common";
import { addRole } from "../user/common";
import { updateRole } from "../user/common";

export default {
  data() {
    return {
      tableData: [],
      currentPage: 1,
      pageSize: 4,
      total: 0,
      //设置权限
      juese: "管理员",
      dialogVisible: false,
      data: [
        {
          id: 1,
          label: "首页"
        },
        {
          id: 2,
          label: "商品",
          children: [
            {
              id: 5,
              label: "品类管理"
            },
            {
              id: 6,
              label: "商品管理"
            }
          ]
        },
        {
          id: 3,
          label: "用户",
          children: [
            {
              id: 7,
              label: "用户管理"
            },
            {
              id: 8,
              label: "权限管理"
            }
          ]
        },
        {
          id: 4,
          label: "订单",
          children: [
            {
              id: 9,
              label: "订单管理"
            }
          ]
        }
      ],
      defaultProps: {
        children: "children",
        label: "label"
      }
    };
  },
  methods: {
    setTableData() {
      getRoleList({ pageNum: this.currentPage, pageSize: this.pageSize }).then(
        res => {
          if (res.data.status == 0) {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        }
      );
    },
    current_change(currentPage) {
      this.currentPage = currentPage;
      this.setTableData();
    },
    timestampToTime(timestamp) {
      let date = new Date(timestamp); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
      let Y = date.getFullYear() + "-";
      let M =
        (date.getMonth() + 1 < 10
          ? "0" + (date.getMonth() + 1)
          : date.getMonth() + 1) + "-";
      let D = date.getDate() + " ";
      let h = date.getHours() + ":";
      let m = date.getMinutes() + ":";
      let s = date.getSeconds();
      return Y + M + D + h + m + s;
    },
    //创建角色
    handleAdd() {
      console.log(1);
      this.$prompt("输入角色名", "添加角色", {
        confirmButtonText: "确定",
        cancelButtonText: "取消"
      })
        .then(({ value }) => {
          addRole({ roleName: value }).then(res => {
            if (res.data.status == 0) {
              this.setTableData();
              console.log("添加成功");
            }
          });

          this.$message({
            type: "success",
            message: "你的邮箱是: " + value
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "取消输入"
          });
        });
    },
    //设置权限

    handleJurisdiction(index, row) {
      // console.log(index);
      // console.log(row);
      this.dialogVisible = true;
      this.juese = row.name;
      row = JSON.stringify(row);
      localStorage.row = row;
    },
    //确定设置
    DetermineJurisdiction() {
      this.dialogVisible = false;
      let row = JSON.parse(localStorage.getItem("row"));
      updateRole({
        _id: row._id,
        menus: [
          "/#/home/role",
          "/#/home/index",
          "/#/home/category",
          "/#/home/product",
          "/#/home/user",
          "/#/home/role",
          "/#/home/order",
        ],
        auth_time:row.auth_time,
        auth_name:row.auth_name
      }).then(res=>{
        if(res.data.status==0){
          console.log('权限设置成功')
        }
      })
    },
    //关闭
    handleClose(done) {
      this.$confirm("确认关闭？")
        .then(_ => {
          done();
        })
        .catch(_ => {});
    }
  },
  mounted() {
    this.setTableData();
  }
};
</script>
<style lang="less" scoped>
.role_box {
  width: 100%;
  height: 520px;
  position: relative;
  overflow: hidden;
}

.header_box {
  width: 100%;
  height: 75px;
  padding: 0 15px;
  box-sizing: border-box;
  border-bottom: 1px solid gainsboro;
  margin-bottom: 30px;
}

.header_left {
  float: left;
  font-size: 12px;
  line-height: 0px;
  height: 20px;
  background-color: rgba(64, 158, 255);
  margin-top: 20px;
  padding: 15px 18px;
  color: white;
  box-sizing: border-box;
  border-radius: 4px;
  cursor: pointer;
  margin-left: 10px;
}

.role_list {
  border: 1px solid gainsboro;
  width: 95%;
  position: absolute;
  left: 50%;
  transform: translatex(-50%);
}

.role_pagination {
  position: absolute;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
}
.jurisdiction {
  display: flex;
  justify-content: center;
}
</style>
