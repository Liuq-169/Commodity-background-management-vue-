<template>
  <div class="warppre">
    <div class="header">
      <i class="el-icon-back" @click="goProduct"></i>
      订单详情
    </div>
    <div class="o_detailBox">
      <div>
        <span class="o_item">订单号</span>
        <span>{{tableData.orderId}}</span>
      </div>
      <div>
        <span class="o_item">订单人</span>
        <span>{{tableData.recipient}}</span>
      </div>
      <div>
        <span class="o_item">创建时间</span>
        <span>{{tableData.create_time}}</span>
      </div>
      <div>
        <span class="o_item">订单状态</span>
        <span>{{getStatus(tableData.status) }}</span>
      </div>
      <div>
        <span class="o_item">商品价格</span>
        <span>￥{{tableData.allPrice}}元</span>
      </div>
      <div>
        <span class="o_item">支付方式</span>
        <span>支付宝</span>
      </div>
      <el-divider>
        <i class="el-icon-shopping-cart-2"></i>
      </el-divider>
    </div>

    <div class="p_detailBox">
      <el-table :data="tableDataB" border style="width: 100%">
        <el-table-column prop="name" label="商品名称" width="120"></el-table-column>
        <el-table-column prop="imgs" label="商品图片" width="300">
            <el-image src='src'></el-image>
        </el-table-column>
        <el-table-column prop="info" label="商品信息" width="300"></el-table-column>
        <el-table-column prop="price" label="单价" width="130"></el-table-column>
        <el-table-column prop="count" label="数量"></el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>

import { orderInfo } from "../user/common";
export default {
  data() {
    return {
      tableData: [],
      tableDataB:[],
      src:''
    };
  },
  methods: {
    //跳转到订单主页
    goProduct() {
      this.$router.push({
        path: "/home/Order"
      });
    },
    handleInfo() {
      orderInfo({ id: this.$route.query._id }).then(res => {
        console.log(res);
        this.tableData = res.data.data;
        this.tableDataB = res.data.data.details
        console.log( this.tableData);
        console.log(this.tableDataB);
        this.src = res.data.data.details[0].imgs[0]
        console.log(this.src);
        
      });
    },
    getStatus(status) {
      if (status == 1) {
        return "未支付";
      } else if (status == 0) {
        return "已支付";
      }
    },
  },
  mounted() {
    this.handleInfo();
  }
};
</script>

<style lang="less" scoped>
.header {
  padding: 0px 35px 0px 35px;
  font-size: 20px;
  text-align: left;
  height: 80px;
  box-sizing: border-box;
  line-height: 80px;
  border-bottom: 1px solid gainsboro;
}
.header > .el-icon-back {
  cursor: pointer;
  color: deepskyblue;
}
.o_detailBox {
  height: 285px;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  align-items: start;
  padding: 35px 35px 0px 35px;
  font-size: 10px;
}
.o_item {
  background-color: rgb(236, 245, 255);
  display: inline-block;
  padding: 0px 5px;
  color: #409eff;
  border-radius: 4px;
  margin-right: 10px;
  width: 50px
}
.p_detailBox {
  padding: 0 35px 5px 35px;
}
</style>